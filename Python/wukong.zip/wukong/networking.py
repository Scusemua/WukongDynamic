class ServerlessNetwork(object):
    def __init__(self):
        pass

class ServerlessNetworkingUniSenderHelper(object):
    def __init__(self):
        pass

class ServerlessNetworkingUniReceiverHelper(object):
    def __init__(self):
        pass